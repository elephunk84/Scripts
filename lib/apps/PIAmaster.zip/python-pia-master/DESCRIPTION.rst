Private Internet Access Configuration
=====================================
-----------------
Command-line tool
-----------------

This project auto configures Private Internet Access (https://www.privateinternetaccess.com/) for Network Manager,
Connman, and OpenVPN for Arch Linux. Currently, this package is untested on any other Linux distro other then
Arch Linux (http://www.archlinux.org).

More information can be found on the Arch Wiki site: https://wiki.archlinux.org/index.php/Private_Internet_Access_VPN
